import { myName } from "../script.js";

export function greet(){
  alert(`Привет,  ${myName}`);
}