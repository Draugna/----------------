export function concatStrings(){
  var word1 = prompt("Введите первое слово:", "Ваше слово");
  console.log(word1);
  var word2 = prompt("Введите второе слово:", "Ваше слово");
  console.log(word2);
  alert(`Первое слово - ${word1}, Второе слово - ${word2}`);
}